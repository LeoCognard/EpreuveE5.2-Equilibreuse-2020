/*
 * UlAiChanInfo.h
 *
 *     Author: Measurement Computing Corporation
 */

#ifndef INTERFACES_ULAICHANINFO_H_
#define INTERFACES_ULAICHANINFO_H_

#include "../uldaq.h"

namespace ul
{

class UlAiChanInfo
{
public:
	virtual ~UlAiChanInfo(){};
};

} /* namespace ul */

#endif /* INTERFACES_ULAICHANINFO_H_ */
